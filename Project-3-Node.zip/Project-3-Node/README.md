# Project-3-Node

This is server responds to GET and POST requests.  GET returns all user information in an ugly JSON format.  POST takes a user's data in a JSON format and loads it to the server.  The user's name, mpg, car make, car model, and car year is packaged in a JSON file and sent to the server to be shared with the world.
